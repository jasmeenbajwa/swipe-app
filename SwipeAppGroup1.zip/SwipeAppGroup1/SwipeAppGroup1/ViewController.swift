//
//  ViewController.swift
//  SwipeAppGroup1
//
//  Created by jasmeen kaur on 10/08/20.
//  Copyright © 2020 Group 1. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var bgImage: UIImageView!
    @IBOutlet var titleLabel: UILabel!
    @IBOutlet var descLabel: UILabel!
    @IBOutlet var goButton: UIButton!
    @IBOutlet var findLabel: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
      
        bgImage.alpha = 0
        titleLabel.alpha = 0
        descLabel.alpha = 0
        goButton.alpha = 0
        findLabel.alpha = 0
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        UIView.animate(withDuration: 1, animations: {
            self.bgImage.alpha = 0.8
        }) { (true) in
            self.showTitle()
        }
        
    }
    func showTitle() {
        UIView.animate(withDuration: 1, animations:{
            self.titleLabel.alpha = 1
        }, completion: { (true) in
            self.showDesc()
        })
        
    }
    func showDesc() {
        UIView.animate(withDuration: 1, animations: {
            self.descLabel.alpha = 1
        }) {(true) in
            self.showButtonAndText()
        }
        }
        
        func showButtonAndText() {
            UIView.animate(withDuration: 1, animations: {
                self.goButton.alpha = 1
                self.findLabel.alpha = 1
            })
        }
}

