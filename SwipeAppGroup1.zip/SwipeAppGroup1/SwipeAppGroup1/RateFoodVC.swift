//
//  RateFoodVC.swift
//  SwipeAppGroup1
//
//  Created by jasmeen kaur on 12/08/20.
//  Copyright © 2020 Group 1. All rights reserved.
//

import UIKit

class RateFoodVC: UIViewController {
      
    @IBOutlet weak var menuView: UIView!
    @IBOutlet weak var darkFillView: UIView!
    @IBOutlet weak var toogleMenuButton: UIButton!
    
    
    @IBOutlet weak var card: UIView!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func toogleMenu( sender: UIButton) {
        UIView.animate(withDuration: 1, animations: {
            self.darkFillView.transform = CGAffineTransform(scaleX: 11, y: 11)
        }) { (true) in
            
        }
    }
  
    @IBAction func panCard(_ sender: UIPanGestureRecognizer) {
        let card = sender.view!
        let point = sender.translation(in: view)
       
        card.center = CGPoint(x: view.center.x + point.x, y: view.center.y + point.y)
       
        if sender.state == UIGestureRecognizer.State.ended {
        
        UIView.animate(withDuration: 0.2, animations: {
            card.center = self.view.center
        })
        }
        
        
        
        
    }

}
